<template>
  <img src="../../assets/icons/home/Group%204.png" alt="search icon"
       style="width: 3vh;height: 3vh;margin: 10px"
  />
</template>

<script setup>

</script>
<style scoped>

</style>