<template>
  <el-image :src="icon" alt="search icon"
       style="width: 1vh;height: 1vh;margin: 10px"
  />
</template>

<script setup>
import icon from '@/assets/icons/board/Frame.png';

</script>
<style scoped>

</style>