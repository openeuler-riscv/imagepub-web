<template>
  <img src="../../assets/icons/home/Group%205.png" alt="search icon"
       style="width: 1vh;height: 1vh;margin: 10px"
  />
</template>

<script setup>

</script>

<style scoped>

</style>