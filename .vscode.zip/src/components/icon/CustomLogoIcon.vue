<template>
  <img src="../../assets/logo/Frame1@3x.svg" alt="search icon"
       style="width: 160px;height: 100px;margin: 10px"
  />
</template>

<script setup>

</script>


<style scoped>

</style>